1. install node js (baca dokumentasi)
2. instalasi proyek (npm init -y)
3. instalasi modul eksternal (npm install express body-parser mongoose bcrypt jsonwebtoken)
    express: Framework untuk membuat server web.
    body-parser: Middleware untuk menangani data permintaan HTTP.
    mongoose: ODM (Object Data Modeling) untuk MongoDB.
    bcrypt: Untuk mengenkripsi dan membandingkan kata sandi.
    jsonwebtoken: Untuk menghasilkan dan memverifikasi token JWT.
4. running server (node index.js)